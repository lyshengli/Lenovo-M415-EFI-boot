## 针对本机型的 SSDT 补丁
> 请自行下载 [SSDTTime](https://github.com/corpnewt/SSDTTime) 选择需要的补丁。

## 关于唤醒
> 参考 https://dortania.github.io/OpenCore-Post-Install/usb/misc/instant-wake.html 加入需要的内容。 
